import sys, os

from .gui import GUI

def Start():
    gui = GUI()
    gui.GUI()